# TheWebNote — Engineering Journal

A personal log of real problems encountered during development, how they were diagnosed, and how they were solved or worked around. Written for interview preparation and personal reference.

---

## 1. Empty State Not Rendering After Last Note Deleted

**Problem:**
When the last note was deleted from the popup, the "nothing to show" illustration never appeared. The task container stayed blank.

**Root Cause:**
In `noteService.js`, the `RenderNothingToShow` function was referenced but never called:
```js
remainingNotes.length === 0 && RenderNothingToShow; // missing ()
```
The `&&` expression evaluated the function reference and discarded it. No invocation happened.

**Fix:**
```js
remainingNotes.length === 0 && RenderNothingToShow();
```
One character — added `()` to actually call the function.

**Lesson:**
JavaScript won't throw an error if you reference a function without calling it. Always double check that event handlers and conditional callbacks are actually being invoked, not just referenced.

---

## 2. Manifest utils Wildcard Unreliable

**Problem:**
All utility files were covered by a single `"utils/*"` wildcard in `web_accessible_resources` in `manifest.json`. Chrome's MV3 handling of wildcards for ES modules can be inconsistent, meaning individual utils modules could silently fail to load inside the iframe popup.

**Root Cause:**
Wildcards in `web_accessible_resources` are reliable for static assets like images and SVGs but not guaranteed for JavaScript ES modules loaded dynamically.

**Fix:**
Replaced `"utils/*"` with explicit entries for every utils file:
```json
"utils/date.js",
"utils/events.js",
"utils/helpers.js",
...
```

**Lesson:**
In Chrome extensions, always be explicit about JS module paths in `web_accessible_resources`. Wildcards are fine for assets but risky for modules.

---

## 3. Toggle Pill Counts Not Updating Correctly

**Problem:**
When notes were added or deleted while the toggle pill was visible on the page, the pill counts sometimes displayed incorrectly or failed to update.

**Root Cause:**
In `refreshToggleCounts`, the divider and counts wrapper were selected using:
```js
const children = pill.querySelectorAll("span");
const divider  = children[0];
const countsEl = children[1];
```
But the counts wrapper itself contained nested spans (dots, numbers, separators), so `querySelectorAll("span")` returned ALL spans including nested ones. The index assumptions were completely unreliable.

**Fix:**
Added stable IDs to the divider and counts wrapper at creation time:
```js
divider.id  = "webnote-divider";
countsEl.id = "webnote-counts";
```
Then selected them directly in `refreshToggleCounts`:
```js
const divider  = document.getElementById("webnote-divider");
const countsEl = document.getElementById("webnote-counts");
```

**Lesson:**
Never rely on DOM index assumptions for elements that contain nested children of the same tag. Use stable IDs or data attributes for reliable selection.

---

## 4. Notes Occasionally Not Saving (Race Condition)

**Problem:**
Rarely (about 5 in 100 times), adding a note — especially the first note after opening the popup — would silently disappear. The note was not saved anywhere in IndexedDB.

**Root Cause:**
In `urls.js`, `activeTabUrl` was set asynchronously via `chrome.tabs.query` callback but exported and consumed as a plain string:
```js
let activeTabUrl = "";
getActiveTabUrl((url) => { activeTabUrl = url; }); // async
```
If the user clicked "Add Task" before the callback resolved, `activeTabUrl` was still `""`. `urlExtract("")` returned `undefined`, and `store.put(siteData, undefined)` either silently failed or wrote to an undefined key.

**Fix:**
Replaced the plain string export with a Promise:
```js
export const activeTabUrlPromise = new Promise((resolve) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    resolve(tabs[0]?.url || "");
  });
});
```
Then awaited it before using:
```js
async function handleAddNote() {
  const activeTabUrl = await activeTabUrlPromise;
  ...
}
```

**Lesson:**
Never consume async data as if it's synchronous. If a value depends on an async operation, model it as a Promise from the start. Race conditions in extensions are especially sneaky because they're timing-dependent and hard to reproduce consistently.

---

## 5. Image Storage Bloating IndexedDB

**Problem:**
Images were stored as raw base64 strings with no compression or size limit. A typical phone photo at 3-8MB becomes 4-11MB as base64, slowing down every IndexedDB read.

**Root Cause:**
No compression was applied before storing. `fileToBase64` simply converted the file directly.

**Fix:**
Rewrote `fileToBase64` in `helpers.js` to run the image through a canvas before returning:
- Resize to max 1200px on the longest side
- JPEG images compressed at 0.75 quality
- PNG images resized only, no quality loss (lossless)

```js
const canvas = document.createElement("canvas");
canvas.width  = width;
canvas.height = height;
canvas.getContext("2d").drawImage(img, 0, 0, width, height);
resolve(canvas.toDataURL(mimeType, quality));
```

**Lesson:**
Always compress user-provided images before storing them in a client-side database. Base64 is already 33% larger than binary — uncompressed images on top of that can seriously degrade performance at scale.

---

## 6. Inline onclick Violates Content Security Policy

**Problem:**
When adding click-to-view functionality for note images, the first attempt used an inline event handler:
```js
`<img onclick="window.open(this.src, '_blank')">`
```
Chrome blocked this with:
```
Executing inline event handler violates Content Security Policy directive 'script-src 'self''
```

**Root Cause:**
Chrome extensions enforce strict CSP that blocks all inline JavaScript — including inline event handlers, `javascript:` URLs, and `eval`. This is a security feature of MV3.

**Fix:**
Used event delegation instead — added a CSS class and data attribute to the image, then attached a global listener:
```js
export function initImageViewer() {
  addGlobalEventListner("click", ".note-image-view", (e) => {
    const blob = // convert base64 to blob URL
    window.open(blobUrl, "_blank");
  });
}
```

**Lesson:**
Chrome extensions block all inline JavaScript via CSP. Always use event listeners attached via JavaScript, never inline handlers. This applies to `onclick`, `onload`, `onerror` attributes and `javascript:` URLs.

---

## 7. Opening Base64 Data URLs Blocked in New Tab

**Problem:**
After fixing the CSP issue, the next attempt opened the image using:
```js
window.open(dataUrl, "_blank");
```
Chrome blocked this with:
```
Not allowed to navigate top frame to data URL
```

**Root Cause:**
Chrome blocks navigation to `data:` URLs in the top frame as a phishing prevention measure introduced in Chrome 60.

**Fix:**
Convert the base64 data URL to a temporary Blob URL before opening:
```js
const blob    = // base64 → Blob conversion
const blobUrl = URL.createObjectURL(blob);
window.open(blobUrl, "_blank");
```
Blob URLs (`blob:chrome-extension://...`) are allowed to open in new tabs.

**Lesson:**
`data:` URLs cannot be used for top-frame navigation in Chrome. Use `URL.createObjectURL()` to create a temporary Blob URL instead. Always revoke it with `URL.revokeObjectURL()` after use to avoid memory leaks.

---

## 8. External CDN Scripts Blocked by CSP

**Problem:**
Multiple attempts to load third-party libraries from CDN failed:
```
Loading the script 'https://cdnjs.cloudflare.com/...' violates Content Security Policy
```
This happened with JSZip, jsPDF, html2canvas, and ExcelJS.

**Root Cause:**
Chrome extensions only allow scripts from `'self'` by default — meaning only files bundled with the extension can be loaded. External URLs are blocked regardless of how trusted the CDN is.

**Fix:**
Download all third-party libraries locally, save them to `libs/`, and load them from there:
```html
<script src="../libs/jszip.min.js" defer></script>
```
Also add them to `web_accessible_resources` in `manifest.json`.

**Lesson:**
Chrome extensions cannot load external scripts. All third-party libraries must be vendored locally. This is both a security feature and a reliability feature — your extension works offline and is not dependent on CDN availability.

---

## 9. File System Access API Blocked in Extension Pages

**Problem:**
Attempted to use `showSaveFilePicker` and `showDirectoryPicker` to let users choose where to save export files. Both threw a `DOMException` and were silently blocked.

**Root Cause:**
The File System Access API (`showSaveFilePicker`, `showDirectoryPicker`) is blocked in Chrome extension pages. Extension pages are not considered a valid browsing context for these APIs due to security restrictions.

**Workaround:**
Used `chrome.downloads` API instead, which downloads files to the user's Downloads folder with a custom subfolder:
```js
chrome.downloads.download({
  url:      blobUrl,
  filename: "TheWebNote-Exports/export-github.com.json",
  saveAs:   false,
});
```
All exports go to `Downloads/TheWebNote-Exports/` automatically.

**Lesson:**
Not all browser APIs are available in extension pages. The File System Access API, in particular, is restricted to normal web pages. When building extensions, always verify API availability in the extension context before designing a feature around it.

---

## 10. contentDocument.write() Deprecated

**Problem:**
The initial PDF generation approach used an iframe with `contentDocument.write()` to inject HTML for printing:
```js
iframe.contentDocument.write(html);
```
This triggered a deprecation warning in the console.

**Fix:**
Replaced with a Blob URL approach:
```js
const blob = new Blob([html], { type: "text/html" });
iframe.src = URL.createObjectURL(blob);
iframe.onload = () => iframe.contentWindow.print();
```

**Lesson:**
`document.write()` and `contentDocument.write()` are deprecated in modern browsers. Use Blob URLs or `srcdoc` attribute to inject HTML into iframes dynamically.

---

## 11. PDF Page Break Cutting Notes in Half  --Interesting one...

**Problem:**
When generating multi-page PDFs using html2canvas, notes were being cut in the middle at page boundaries — half a note card on one page, the other half on the next.

**Root Cause:**
The html2canvas approach captures everything as one giant image and slices it at fixed intervals. It has no concept of where individual note cards start and end — it just cuts the image at the page height boundary regardless of content.

**Fix:**
Dropped html2canvas entirely and switched to pure jsPDF primitives with a two-pass layout system:
- **Pass 1** — measure every note card height, calculate where each row falls, decide page breaks
- **Pass 2** — draw everything using the layout decisions from Pass 1

If a row doesn't fit in the remaining space on the current page, it moves entirely to the next page. No mid-note cuts ever.

**Lesson:**
When generating paginated documents programmatically, never slice a rendered image at fixed intervals. Instead, measure content height before rendering and make page break decisions based on content boundaries.

---

## 12. EXIF Rotation in PDF Images --Interesting one...

**Problem:**
Photos taken on phones appeared rotated in the exported PDF — a portrait photo would show as landscape or upside down.

**Root Cause:**
JPEG images taken on phones contain an EXIF orientation tag that tells browsers how to display them. Browsers apply this rotation automatically when rendering images. But jsPDF reads raw pixel data and ignores the EXIF tag entirely, so images appear in their raw unrotated state.

**Fix:**
Before passing images to jsPDF, normalize them through a canvas:
```js
function normalizeImage(base64) {
  return new Promise((resolve) => {
    const img  = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width  = img.naturalWidth;
      canvas.height = img.naturalHeight;
      canvas.getContext("2d").drawImage(img, 0, 0);
      resolve(canvas.toDataURL("image/jpeg", 0.92));
    };
    img.src = base64;
  });
}
```
When the browser draws the image to canvas it applies the EXIF rotation. The canvas output has no EXIF tag — the rotation is baked into the pixels.

**Lesson:**
EXIF orientation is a common gotcha when processing images programmatically. Browsers handle it automatically in `<img>` tags but not in canvas or PDF contexts. Always normalize images through canvas before passing them to libraries that process raw pixel data.

---

## 13. ExcelJS Blocked by CSP eval()

**Problem:**
ExcelJS was chosen for styled XLSX export but threw:
```
Uncaught EvalError: Evaluating a string as JavaScript violates Content Security Policy
```

**Root Cause:**
ExcelJS uses `eval()` or `new Function()` internally for some of its processing. Chrome extensions block `eval` via CSP — `'unsafe-eval'` is not permitted in MV3 extensions.

**Attempted Fix:**
Adding the file to `web_accessible_resources` was not the issue — the library itself fundamentally relies on eval and cannot run in an extension context regardless.

**Workaround:**
Feature dropped for now. Will revisit using either a dynamic import approach or building XLSX from scratch using JSZip + raw XML (XLSX is a ZIP of XML files under the hood).

**Lesson:**
Before choosing a third-party library for use in a Chrome extension, check whether it uses `eval`, `new Function`, or dynamic code execution. These are all blocked by MV3 CSP and cannot be worked around without modifying the library itself.

---

## 14. SheetJS Community Edition Does Not Support Cell Styling

**Problem:**
SheetJS (`xlsx.full.min.js`) was chosen for XLSX export with colored priority cells. After implementation, all styling was silently ignored — cells had no colors, fonts, or borders.

**Root Cause:**
SheetJS community edition does not support cell styling. The `s` property (style) on cells is only processed by SheetJS Pro, which is a paid product. The free version ignores all style properties without throwing any errors.

**Lesson:**
Always verify that the specific features you need are available in the free/open-source version of a library before building around it. SheetJS is a well known library but its styling support is paywalled. ExcelJS is the correct free alternative — but in this case it was blocked by CSP (see issue 13).

---

## 15. html2canvas Not Capturing Text-Only Notes

**Problem:**
Text-only notes (no image) were not appearing in the captured canvas when using html2canvas for PDF generation.

**Root Cause:**
The hidden container used `position: fixed` which takes elements out of the document flow entirely and positions them relative to the viewport. Grid layout inside a `fixed` element behaves unpredictably — some cells were not being laid out or rendered correctly off-screen.

**Fix:**
Changed `position: fixed` to `position: absolute` on the hidden container. `absolute` keeps the element in the document flow but positions it off-screen, so grid layout works correctly and html2canvas captures all content.

**Note:**
This issue was ultimately rendered moot when the entire html2canvas approach was replaced with pure jsPDF primitives (see issue 11).

**Lesson:**
`position: fixed` removes elements from the document flow entirely. When capturing off-screen content with html2canvas or similar tools, use `position: absolute` instead so the browser lays out the content correctly before capture.

---